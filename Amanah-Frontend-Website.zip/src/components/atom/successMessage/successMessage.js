import React from "react";

const successMessage = () => {
  return <div>successMessage</div>;
};

export default successMessage;
