export const opsiTenor = [
  { value: "1", label: "1 Bulan" },
  { value: "2", label: "2 Bulan" },
  { value: "3", label: "3 Bulan" },
  { value: "4", label: "4 Bulan" },
  { value: "5", label: "5 Bulan" },
  { value: "6", label: "6 Bulan" },
  { value: "7", label: "7 Bulan" },
  { value: "8", label: "8 Bulan" },
  { value: "9", label: "9 Bulan" },
  { value: "10", label: "10 Bulan" },
  { value: "11", label: "11 Bulan" },
  { value: "12", label: "12 Bulan" },
];

export const opsiKategori = [
  { value: "Bisnis Kecil", label: "Bisnis Kecil" },
  { value: "Tempat Tinggal", label: "Tempat Tinggal" },
  { value: "Kesehatan", label: "Kesehatan" },
  { value: "Kendaraan", label: "Kendaraan" },
];
