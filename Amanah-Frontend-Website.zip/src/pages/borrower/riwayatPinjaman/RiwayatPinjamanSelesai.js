import React from "react";

const RiwayatPinjamanSelesai = () => {
  return <div>Riwayat Pinjaman Selesai</div>;
};

export default RiwayatPinjamanSelesai;
