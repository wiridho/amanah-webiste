import React from "react";

const TableLoanHistory = () => {
  return <div>TableLoanHistory</div>;
};

export default TableLoanHistory;
